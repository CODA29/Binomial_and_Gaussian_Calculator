from setuptools import setup

setup( name = 'bino_gaus_probability', 
        version = '1.0',
        description ="Gaussian and Binomial distributions", 
        packages =['bino_gaus_probability'],
        author = 'Dagmawi Megra',
        author_email = 'rasdagm@gmail.com',
    zip_safe = False)
